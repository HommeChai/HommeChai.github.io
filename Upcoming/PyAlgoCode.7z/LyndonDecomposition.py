# Python Version
# LyndonDecomosiion: find a character string s = w_1....w_m
# so that w_i is simple(Lyndon) wih order strict less than its suffix w_1>=..>=w_m
# Example like: acab -> ac,ab
#               abc  -> abc
#               cba  -> c,b,a
#               aaaa -> a,a,a,a
# duval_algorithm
def duval(s):
    n, i = len(s), 0                                    # i is the check pointer
    factorization = []                                  # Lyndon factors
    while i < n:
        j, k = i + 1, i                                 # check a slice from k to j
        while j < n and s[k] <= s[j]:                   
            if s[k] < s[j]:                             # [k,j] is pre-Lyndon
                k = i
            else:                                       # enlarge the [k,j]
                k += 1
            j += 1
        while i <= k:                                   # [k,j] is not pre-Lyndon
            factorization.append(s[i : i + j - k])      # cut the Lyndon prefix
            i += j - k                                  # move the i pointer
    return factorization

# Using duval_algorithm to solve the minimal cyclic representation of string
# example abcd 's minimal repn is abcd
# for 'cba' one can cyclically change to 'bac' then to 'acb' for the minimal repn
# the algorithm is implentmented by find Lyndon decomposion of ss then find the
# last Lyndon factor which has head index less than n
# smallest_cyclic_string
def min_cyclic_string(s):
    s += s
    n = len(s)
    i, ans = 0, 0
    while i<n//2:                                       # do the same thing as dvual
        ans = i                                         # only restrict i<length(s)
        j, k = i + 1, i
        while j < n and s[k] <= s[j]:
            if s[k] < s[j]:
                k = i
            else:
                k += 1
            j += 1
        while i <= k:
            i += j - k
    return s[ans : ans + n // 2]                        # choose i as beginning
    

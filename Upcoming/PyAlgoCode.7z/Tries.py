# Python Version
# Trie tree implementation
# The translation states contain 26 lower letters in English
# node range is 100 one can change it
class trie:
    nodes = 100
    nex = [[0 for i in range(26)] for j in range(nodes)]
    cnt = 0
    exist = [False] * nodes  # 该结点结尾的字符串是否存在

    def insert(self, s):  # 插入字符串
        p = 0
        for i in s:
            c = ord(i) - ord('a')
            if not self.nex[p][c]:
                self.cnt += 1
                self.nex[p][c] = self.cnt  # 如果没有，就添加结点
            p = self.nex[p][c]
        self.exist[p] = True

    def find(self, s):  # 查找字符串
        p = 0
        for i in s:
            c = ord(i) - ord('a')
            if not self.nex[p][c]:
                return False
            p = self.nex[p][c]
        return self.exist[p]

if __name__=="__main__":                    # 测试程序
    example = trie()
    example.insert('absent')
    example.insert('absolute')
    example.insert('cut')
    example.insert('solid')
    print(example.nex)                          



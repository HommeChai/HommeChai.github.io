#   Python Version
#   Segment Tree data structure
class stree:
    def __init__(self, begin, end, *iter):          # 可以传入可迭代对象作为信息
        self.val = 0
        pass

#   最大公因子GCD
def gcd(m, n):                          # 计算最大公因数
        while n>0:
            m, n = n, m%n
        return m


#   寻找子区间的gcd等于k的所有子区间
def subarrayGCD(nums, k):
    ans = 0
    a = []                                  # [以当前x为右端的不同GCD，相同GCD左端最大索引]
    i0 = -1                                 # 小于当前x的不整除k的最大索引
    sub = []                                # sub表示满足条件的子区间
    for i, x in enumerate(nums):
        if x%k>0:                           # 保证后续gcd都是k的倍数
            a = []
            i0 = i
            continue
        a.append([x, i])
        j = 0
        for p in a:                         # 原地去重，因为相同的 GCD 都相邻在一起
            p[0] = gcd(p[0], x)
            if a[j][0] != p[0]:
                j += 1
                a[j] = p
            else:
                a[j][1] = p[1]
        del a[j+1:]
        if a[0][0] == k:                    # a[0][0] >= k 进一步a[][0]严格升序排列
            ans += a[0][1] - i0
            for j in range(i0+1,a[0][1]+1):
                sub.append((j,i))           # 这里输出所有满足条件的子区间
    return ans,sub



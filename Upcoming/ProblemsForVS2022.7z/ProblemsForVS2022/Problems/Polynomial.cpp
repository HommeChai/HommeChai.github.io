#include"Polynomial.h"

//������x����ȡֵ����
double Polynomial::getValue(double x) const{
	//����ʽֵvalueΪ�������ۼӺ�
	double value=coef[0];
	double term=1;
	for(int i=1;i<num_of_terms;i++){
		term *= x;
		value += coef[i]*term;
	}
	return value;
}

void writeToFile(string path){}
//���Ժ���
void TestPoly(){
	double p1[]={5.0, 3.4, -4.0, 8.0},p2[]={0.0, -5.4, 0.0, 3.0, 2.0};
	Polynomial  poly1(p1, sizeof(p1)/sizeof(double)),
				poly2(p2, sizeof(p2)/sizeof(double));
	cout<<"Value of p1 when x=2.5 : "<<poly1.getValue(2.5)<<endl;
	cout<<"Value of p2 when x=3.0 : "<<poly2.getValue(3.0)<<endl;
	writeToFile(".\\");
	return;
}
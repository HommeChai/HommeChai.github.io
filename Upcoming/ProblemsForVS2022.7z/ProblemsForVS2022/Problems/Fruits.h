/*(15-1)Fruits������*/
#include<iostream>
using namespace std;

//ˮ��
class Fruits
{
public:
	Fruits(char* the_name,float the_price);
	~Fruits();
	bool IsFruit(char* name) const;
	char* GetName();
private:
	char name[50];
	float price;
};


//���Ժ���
void Test_15_1();
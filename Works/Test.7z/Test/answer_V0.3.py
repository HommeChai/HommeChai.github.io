from pyqpanda import *
import numpy as np


def question1(n_qubits):
    qvm = CPUQVM()
    qvm.init_qvm()
    qubits = qvm.qAlloc_many(n_qubits)
    result = {}
    '''
    算法实现代码
    '''
    # 宇宙的答案
    # np.random.seed(42)
    # qvc_weight = -2 * np.random.random(n_qubits - 1)

    
    # 作弊模式
    qvc_weight = [-2 * np.arccos(1 / np.sqrt(n_qubits - _)) for _ in range(n_qubits - 1)]

    def updatepara(weight):
        for i in range(len(weight)):
            theta[i].set_value(weight[i])

    theta = []
    for i in range(n_qubits - 1):
        temp = var(qvc_weight[i])
        theta.append(temp)

    target = []
    for i in range(2 ** n_qubits):
        target.append(1 / n_qubits if i > 0 and i & (i - 1) == 0 else 0)

    target = np.array(target)

    qvc = VariationalQuantumCircuit()
    qvc << VariationalQuantumGate_RY(qubits[0], theta[0])
    for index in range(1, n_qubits - 1):
        qvc << VariationalQuantumGate_RY(qubits[index], theta[index]).control(qubits[index - 1])

    for index in list(reversed(range(0, n_qubits - 1))):
        qvc << VariationalQuantumGate_CNOT(qubits[index], qubits[index + 1])
    qvc << VariationalQuantumGate_X(qubits[0])

    def kl(p, q):
        p = np.where(p == 0, 1e-10, p)
        q = np.where(q == 0, 1e-10, q)

        kl = np.sum(p * np.log(p / q))
        return kl

    def loss_func(weight, grad, inter, fcall):
        updatepara(weight)
        newprog = QProg(qvc.feed())
        progout = qvm.prob_run_list(newprog, qubits)
        progout = np.array(progout)
        loss = kl(target, progout)
        return ("", loss)

    optimizer = OptimizerFactory.makeOptimizer(OptimizerType.POWELL)
    optimizer.registerFunc(loss_func, qvc_weight)
    optimizer.setXatol(1.e-20)
    optimizer.setFatol(1.e-20)
    optimizer.setMaxIter(1000)
    optimizer.exec()

    opt_result = optimizer.getResult()

    updatepara(opt_result.para)
    myqprog = QProg()
    mycir = qvc.feed()
    myqprog.insert(mycir)
    testout = qvm.prob_run_dict(myqprog, qubits)
    result = {key: value for key, value in testout.items() if value > 0.01}
    return result


def question2(n_qubits):
    qvm = CPUQVM()
    qvm.init_qvm()
    qubits = qvm.qAlloc_many(n_qubits)
    result = {}
    '''
        算法实现代码
    '''
    # 宇宙的答案
    # np.random.seed(42)
    qvc_weight = -2 * np.random.random(n_qubits - 1)

    # 作弊模式
    # qvc_weight = [-2 * np.arccos(1 / np.sqrt(n_qubits - _)) for _ in range(n_qubits - 1)]

    def updatepara(weight):
        for i in range(len(weight)):
            theta[i].set_value(weight[i])

    theta = []
    for i in range(n_qubits - 1):
        temp = var(qvc_weight[i])
        theta.append(temp)

    target = []
    for i in range(2 ** n_qubits):
        target.append(1 / n_qubits if i > 0 and i & (i - 1) == 0 else 0)

    target = np.array(target)

    qvc = VariationalQuantumCircuit()
    qvc << VariationalQuantumGate_RY(qubits[0], theta[0])
    for index in range(1, n_qubits - 1):
        qvc << VariationalQuantumGate_RY(qubits[index], theta[index]).control(qubits[index - 1])

    for index in list(reversed(range(0, n_qubits - 1))):
        qvc << VariationalQuantumGate_CNOT(qubits[index], qubits[index + 1])
    qvc << VariationalQuantumGate_X(qubits[0])

    def kl(p, q):
        p = np.where(p == 0, 1e-10, p)
        q = np.where(q == 0, 1e-10, q)

        kl = np.sum(p * np.log(p / q))
        return kl

    def loss_func(weight, grad, inter, fcall):
        updatepara(weight)
        newprog = QProg(qvc.feed())
        progout = qvm.prob_run_list(newprog, qubits)

        progout = np.array(progout)
        loss = kl(target, progout)

        return ("", loss)

    optimizer = OptimizerFactory.makeOptimizer(OptimizerType.POWELL)
    optimizer.registerFunc(loss_func, qvc_weight)
    optimizer.setXatol(1.e-20)
    optimizer.setFatol(1.e-20)
    optimizer.setMaxIter(1000)
    optimizer.exec()

    opt_result = optimizer.getResult()
    # print("loss:", opt_result.fun_val)
    # print("iterations:", opt_result.iters)
    updatepara(opt_result.para)
    myqprog = QProg()
    mycir = qvc.feed()
    myqprog.insert(mycir)
    testout = qvm.prob_run_dict(myqprog, qubits)
    result = {key: value for key, value in testout.items() if value > 0.01}
    return result


#   测试方案
for i in range(2, 11):
    print(question1(i))

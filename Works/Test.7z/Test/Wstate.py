from pyqpanda import *
from numpy import *


def three_qubits_W_state():
    """
    直接构造法生成3-qubits W-态
    :return:
    """
    qvm = CPUQVM()
    qvm.init_qvm()
    qubits = qvm.qAlloc_many(3)
    cbits = qvm.cAlloc_many(3)

    # 量子程序
    prog = QProg()
    three_qubits_circuit = QCircuit()

    three_qubits_circuit << RY(qubits[0], -2 * arccos(1 / sqrt(3))) \
        << RY(qubits[1], -2 * pi / 4).control(qubits[0]) << CNOT(qubits[1], qubits[2]) \
        << CNOT(qubits[0], qubits[1]) << X(qubits[0])

    draw_qprog(three_qubits_circuit, 'pic', filename='D:/QPanda2/Test/three_qubits_W_state')

    # 测量
    prog << three_qubits_circuit << measure_all(qubits, cbits)
    result = qvm.run_with_configuration(prog, cbits, 1000)
    return result


def four_qubits_W_state():
    """
        直接构造法生成3-qubits W-态
        尝试用VQA拟合角度
        :return:
    """
    qvm = CPUQVM()
    qvm.init_qvm()
    qubits = qvm.qAlloc_many(4)
    cbits = qvm.cAlloc_many(4)

    # 量子程序
    prog = QProg()
    four_qubits_circuit = QCircuit()

    four_qubits_circuit << RY(qubits[0], -2 * pi / 3) << RY(qubits[1], -2 * arccos(1 / sqrt(3))).control(qubits[0]) \
        << RY(qubits[2], -2 * pi / 4).control(qubits[1]) << CNOT(qubits[2], qubits[3]) \
        << CNOT(qubits[1], qubits[2]) << CNOT(qubits[0], qubits[1]) << X(qubits[0])

    draw_qprog(four_qubits_circuit, 'pic', filename='D:/QPanda2/Test/four_qubits_W_state')

    # 测量
    prog << four_qubits_circuit << measure_all(qubits, cbits)
    result = qvm.run_with_configuration(prog, cbits, 50000)
    return result


def w_state(n_qubits):
    """
    直接线路制备n-比特W-态
    :param n_qubits:    比特数
    :return:    各量子基态测量结果 dir 格式
    """
    # 初始化量子虚拟机
    qvm = CPUQVM()
    qvm.init_qvm()
    qubits = qvm.qAlloc_many(n_qubits)
    cbits = qvm.cAlloc_many(n_qubits)
    theta = [-2 * arccos(1 / sqrt(n_qubits - _)) for _ in range(n_qubits - 1)]

    # 构建量子程序
    W_state_prog = QProg()
    W_state_circuit = QCircuit()

    # 构建线路
    if n_qubits == 1:
        W_state_circuit << X(qubits[0])
    elif n_qubits == 2:
        W_state_circuit << H(qubits[0]) << CNOT(qubits[0], qubits[1]) << X(qubits[0])
    else:
        W_state_circuit << RY(qubits[0], theta[0])
        for index in range(1, n_qubits - 1):
            W_state_circuit << RY(qubits[index], theta[index]).control(qubits[index - 1])
        for index in range(2, n_qubits + 1):
            W_state_circuit << CNOT(qubits[n_qubits - index], qubits[n_qubits - index + 1])
        W_state_circuit << X(qubits[0])

    # 绘制线路图
    draw_qprog(W_state_circuit, 'pic', filename=f'D:/QPanda2/Test/{n_qubits}_qubits_W_state')

    # 测量
    W_state_prog << W_state_circuit << measure_all(qubits, cbits)
    result = qvm.prob_run_dict(W_state_circuit, qubits)
    return result


if __name__ == '__main__':
    print(four_qubits_W_state())
    for index in range(2, 11):
        print(w_state(index))

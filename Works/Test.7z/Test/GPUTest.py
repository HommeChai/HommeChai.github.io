from pyvqnet import DEV_GPU_0
from pyvqnet.tensor import *

if __name__ == "__main__":
    a = ones([4, 5], device=DEV_GPU_0)
    print(a)

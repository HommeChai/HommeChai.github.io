from pyqpanda import *
import numpy as np
import pyvqnet as pv

n_qubits = 10

qvm = CPUQVM()
qvm.init_qvm()
qubits = qvm.qAlloc_many(n_qubits)
result = {}

# qvc参数
qvc_weight = np.random.uniform(0, np.pi, 2 ** n_qubits)
# 目标概率
target = []
for i in range(2 ** n_qubits):
    target.append(1 / n_qubits if i > 0 and i & (i - 1) == 0 else 0)

target = np.array(target)
# ry门控制比特
contr = [[0]]
for i in range(1, n_qubits):
    temp = []
    for j in list(reversed(range(i))):
        temp += contr[j]
    temp.append(i)
    contr.append(temp)


# n=4:[[0], [0, 1], [0, 1, 0, 2], [0, 1, 0, 2, 0, 1, 0, 3]]

# 搭qvc
def make_qvc(weight):
    w_i = 0
    qvc = VariationalQuantumCircuit()
    qvc << VariationalQuantumGate_RY(qubits[0], weight[w_i])
    w_i += 1
    for j in range(n_qubits - 1):
        for i in range(2):
            for k in contr[j]:

                for l in range(k + 1):
                    # print(l,end=' ')
                    qvc << VariationalQuantumGate_X(qubits[l])
                # print('fuck:{}'.format(j+1))
                qvc << VariationalQuantumGate_RY(qubits[j + 1], weight[w_i]).control(qubits[:j + 1])
                w_i += 1

    mycir = qvc.feed()
    myqprog = QProg()
    myqprog.insert(mycir)
    # print(myqprog)
    return myqprog


def loss_func(weight, grad, inter, fcall):
    progout = qvm.prob_run_list(make_qvc(weight), qubits)
    progout = np.array(progout)
    loss = np.sum((progout - target) ** 2) / n_qubits
    return ("", loss)


optimizer = OptimizerFactory.makeOptimizer(OptimizerType.POWELL)
optimizer.registerFunc(loss_func, qvc_weight)
optimizer.setXatol(1.e-10)
optimizer.setFatol(1.e-10)
optimizer.setMaxIter(20000)
optimizer.exec()

opt_result = optimizer.getResult()
print(opt_result.message)
print("loss:", opt_result.fun_val)
print("iterations:", opt_result.iters)
print("weight:", opt_result.para)
last_qvc = make_qvc(opt_result.para)
testout = qvm.prob_run_list(last_qvc, qubits)
sf = '{:0' + str(n_qubits) + 'b}'
for i in range(2 ** n_qubits):
    if i > 0 and i & (i - 1) == 0:
        result[sf.format(i)] = testout[i]
print(result)
# print(target)

from QClassifier import test

test()
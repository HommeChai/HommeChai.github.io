from numpy import pi
from pyqpanda import *
from pyqpanda.Visualization import circuit_draw

machine = CPUQVM()
machine.init_qvm()

qlist = machine.qAlloc_many(4)
clist = machine.cAlloc_many(4)

measure_prog = QProg()
measure_prog << hadamard_circuit(qlist) \
<< CZ(qlist[1], qlist[2]) \
<< RX(qlist[2], pi / 4) \
<< RX(qlist[1], pi / 4) \
<< CNOT(qlist[0], qlist[2]) << iSWAP(qlist[1], qlist[2]).control(qlist[0]) \
<< Measure(qlist[0], clist[0])

print(measure_prog)
draw_qprog(measure_prog, 'pic', filename='D:/QPanda2/Test/test_cir_draw.png')

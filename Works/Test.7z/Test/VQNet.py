import pyvqnet
from pyvqnet.tensor import *

a = arange(1, 25).reshape([2, 3, 4])
print(a)
